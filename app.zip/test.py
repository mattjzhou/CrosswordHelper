import os
from datetime import date

import pandas as pd
import pyodbc
from sqlalchemy import create_engine

server = os.getenv("DB_SERVER")
database = os.getenv("DB_NAME")
username = os.getenv("DB_USERNAME")
password = os.getenv("DB_PASSWORD")
driver = "ODBC+Driver+18+for+SQL+Server"
connection_url = (
    f"mssql+pyodbc://{username}:{password}@{server}/{database}?driver={driver}"
)
engine = create_engine(connection_url)

try:
    # conn = pyodbc.connect(connection_string)
    selected_date = str(date.today())
    print(
        f"""
        select c.clue, c.answer_len, answer, c.total from clues join 
        (select clue, answer_len, count(*) as total from clues group by clue, answer_len) as c 
        on clues.clue = c.clue and clues.answer_len = c.answer_len
        where date = '{selected_date}' and c.total >= 1 order by total desc;
    """
    )
    df = pd.read_sql(
        f"""
        select c.clue, c.answer_len, answer, c.total from clues join 
        (select clue, answer_len, count(*) as total from clues group by clue, answer_len) as c 
        on clues.clue = c.clue and clues.answer_len = c.answer_len
        where date = '{selected_date}' and c.total >= 1 order by total desc;
    """,
        engine,
    )
    print(df)
except Exception as e:
    print(e)
